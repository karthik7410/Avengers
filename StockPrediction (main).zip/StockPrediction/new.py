import base64
import streamlit as st
import numpy as np
import pandas as pd
import yfinance as yf
from tensorflow.keras.models import load_model
import plotly.graph_objects as go
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from textblob import TextBlob
import webbrowser
import datetime
import pytz
from newsapi.newsapi_client import NewsApiClient
import requests
import pandas as pd
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import nltk
from streamlit_lottie import st_lottie
import json
# Function to load Lottie animation from a URL or file
def load_lottie_animation(file_path):
    with open(file_path, "r") as f:
        return json.load(f)

# Load the Lottie animation file (ensure the file path is correct)
lottie_file_path = r"C:\Users\unima\PycharmProjects\StockPrediction\bull.json"
lottie_animation = load_lottie_animation(lottie_file_path)
# Load model with error handling
def load_stock_prediction_model(model_path):
    try:
        model = load_model(model_path)
        return model
    except Exception as e:
        st.error(f"Error loading model: {str(e)}")
        return None


# Path to the model
model_path = r"C:\\Users\\unima\\PycharmProjects\\StockPrediction\\Stock Prediction Model.keras"

# Try loading the model
model = load_stock_prediction_model(model_path)

if model is None:
    st.stop()  # Stop execution if the model could not be loaded

# Check if session state is initialized
if 'show_main_page' not in st.session_state:
    st.session_state.show_main_page = False


# Set background function
def set_background(image_path):
    with open(image_path, "rb") as img_file:
        b64_image = base64.b64encode(img_file.read()).decode()

    # CSS to set the background and style the text and button
    st.markdown(
        f"""
        <style>
        .stApp {{
            background: rgba(0, 0, 0, 0);
            background-image: url(data:image/png;base64,{b64_image});
            background-size: cover;
            background-position: center;
            min-height: 100vh;
        }}
        .welcome-page {{
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            height: 100vh;
            color: black;  /* Change font color to black */
            font-weight: bold;
            font-size: 2em;
            position: absolute;
            top: 0;
            width: 100%;
        }}
        .welcome-page h1 {{
            color: black;  /* Change title color to black */
            font-size: 4em;
            font-weight: bolder;
        }}
        .stButton>button {{
            font-size: 1.2em;
            padding: 12px 24px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }}
        .stButton>button:hover {{
            background-color: #45a049;
        }}
        .market-status {{
            font-size: 1.5em;
            font-weight: bold;
            padding: 10px;
            color: white;
            border-radius: 10px;
        }}
        .market-status.open {{
            background-color: #4CAF50; /* Green for open */
        }}
        .market-status.closed {{
            background-color: #f44336; /* Red for closed */
        }}
        </style>
        """,
        unsafe_allow_html=True
    )

    # Create the structure for the message and button overlay on the image
    st.markdown('<div class="welcome-page">', unsafe_allow_html=True)
    st.title("Welcome to the Stock Market Predictor!")
    st.write("")

    start_button = st.button("Start Prediction")

    if start_button:
        st.session_state.show_main_page = True
        st.rerun()  # Refresh to show the main page
    st.markdown('</div>', unsafe_allow_html=True)


# Welcome Page
if not st.session_state.show_main_page:
    # Set background image
    set_background(r"C:\Users\unima\PycharmProjects\StockPrediction\img2.jpg")

# Define predefined lists of stocks and their corresponding codes for NSE and BSE
nse_stock_map = {
    'Reliance': 'RELIANCE.NS',
    'TCS': 'TCS.NS',
    'Infosys': 'INFY.NS',
    'HDFC Bank': 'HDFCBANK.NS',
    'ICICI Bank': 'ICICIBANK.NS',
    'Bajaj Finserv': 'BAJAJFINSV.NS',
    'Kotak Mahindra Bank': 'KOTAKBANK.NS',
    'Larsen & Toubro': 'LT.NS',
    'ITC': 'ITC.NS',
    'SBI': 'SBIN.NS'
}

bse_stock_map = {
    'Reliance': 'RELIANCE.BO',
    'TCS': 'TCS.BO',
    'Infosys': 'INFY.BO',
    'HDFC Bank': 'HDFCBANK.BO',
    'ICICI Bank': 'ICICIBANK.BO',
    'Bajaj Finserv': 'BAJAJFINSV.BO',
    'Larsen & Toubro': 'LT.BO',
    'ITC': 'ITC.BO',
    'SBI': 'SBIN.BO'
}


# Market Status (NSE and BSE opening and closing times)
def market_status():
    india_tz = pytz.timezone('Asia/Kolkata')
    current_time = datetime.datetime.now(india_tz)

    # NSE/BSE Market Times (Assuming same opening and closing for both exchanges)
    market_open_time = current_time.replace(hour=9, minute=15, second=0, microsecond=0)
    market_close_time = current_time.replace(hour=15, minute=30, second=0, microsecond=0)

    # Determine if markets are open or closed
    if current_time >= market_open_time and current_time <= market_close_time:
        status = "Market is Open"
        status_class = "open"
    else:
        status = "Market is Closed"
        status_class = "closed"

    return status, status_class


# Clock Display
def display_clock():
    india_tz = pytz.timezone('Asia/Kolkata')
    current_time = datetime.datetime.now(india_tz).strftime("%Y-%m-%d %H:%M")
    st.markdown(f"**Current Time (IST):** {current_time}")


# Main Page
if st.session_state.show_main_page:
    st_lottie(lottie_animation, height=300, key="welcome-animation")
    # Display Clock
    display_clock()

    # Streamlit Header
    st.header("Stock Market Predictor with Signals")

    # Display Market Status for NSE and BSE
    nse_status, nse_status_class = market_status()
    bse_status, bse_status_class = market_status()

    st.markdown(f'<div class="market-status {nse_status_class}">NSE Market Status: {nse_status}</div>',
                unsafe_allow_html=True)
    st.markdown(f'<div class="market-status {bse_status_class}">BSE Market Status:{bse_status}</div>',
                unsafe_allow_html=True)

    # Dropdown for selecting NSE or BSE
    exchange = st.selectbox('Select Exchange', ['NSE', 'BSE'])

    # Dropdown for selecting stock name based on the chosen exchange
    if exchange == 'NSE':
        stock_name = st.selectbox('Select Stock Name', list(nse_stock_map.keys()))
        stock_symbol = nse_stock_map[stock_name]
    elif exchange == 'BSE':
        stock_name = st.selectbox('Select Stock Name', list(bse_stock_map.keys()))
        stock_symbol = bse_stock_map[stock_name]

    # Option to enter custom ticker
    custom_ticker = st.text_input('Or, enter custom ticker', '').upper()

    if custom_ticker:
        stock_symbol = custom_ticker
        st.write(f"**Selected Custom Stock:** {stock_symbol}")

    # Provide a button to redirect to Yahoo Finance for further search
    if st.button("Search this ticker on Yahoo Finance"):
        webbrowser.open(f"https://finance.yahoo.com/quote/{stock_symbol}")

    # Display selected stock and exchange
    st.write(f"**Selected Stock:** {stock_name} ({stock_symbol})")

    # Get date range input
    start_date = st.date_input("Start Date", datetime.date(2023, 1, 1))
    end_date = st.date_input("End Date", datetime.date(2024, 12, 13))

    # Download stock data using Yahoo Finance based on selected date range
    data = yf.download(stock_symbol, start=start_date, end=end_date)
    st.subheader('Data Set ')
    st.write(data)

    # Train-Test Split
    data_train = pd.DataFrame(data['Close'][0: int(len(data) * 0.80)])
    data_test = pd.DataFrame(data['Close'][int(len(data) * 0.80):])

    # Scaling
    scaler = MinMaxScaler(feature_range=(0, 1))
    scaler.fit(data_train)
    data_test_scaled = scaler.transform(data_test)

    # Moving Averages (50 and 200 days)
    st.subheader('Moving Averages (50 and 200 Days)')
    data['MA50'] = data['Close'].rolling(window=50).mean()
    data['MA200'] = data['Close'].rolling(window=200).mean()

    fig1 = go.Figure()

    fig1.add_trace(go.Scatter(x=data.index, y=data['MA50'], mode='lines', name='MA 50', line=dict(color='blue')))
    fig1.add_trace(go.Scatter(x=data.index, y=data['MA200'], mode='lines', name='MA 200', line=dict(color='orange')))
    fig1.add_trace(go.Scatter(x=data.index, y=data['Close'], mode='lines', name='Close Price', line=dict(color='red')))

    fig1.update_layout(title='Moving Averages vs Close Price', xaxis_title='Date', yaxis_title='Price',
                       template='plotly_dark')
    st.plotly_chart(fig1)

    # **Bollinger Bands** Calculation and Plot (Static using Matplotlib)
    st.subheader('Bollinger Bands')

    data['BB_Mid'] = data['Close'].rolling(window=20).mean()  # Middle Band (SMA of 20)
    data['BB_Std'] = data['Close'].rolling(window=20).std()  # Standard Deviation (20 periods)
    data['BB_Upper'] = data['BB_Mid'] + (2 * data['BB_Std'])  # Upper Band
    data['BB_Lower'] = data['BB_Mid'] - (2 * data['BB_Std'])  # Lower Band

    fig2, ax2 = plt.subplots(figsize=(10, 6))
    ax2.plot(data.index, data['Close'], label='Close Price', color='blue')
    ax2.plot(data.index, data['BB_Upper'], label='Upper Band', color='green', linestyle='--')
    ax2.plot(data.index, data['BB_Lower'], label='Lower Band', color='red', linestyle='--')
    ax2.plot(data.index, data['BB_Mid'], label='Middle Band (SMA)', color='orange', linestyle=':')
    ax2.fill_between(data.index, data['BB_Lower'], data['BB_Upper'], color='grey', alpha=0.2)
    ax2.set_title('Bollinger Bands')
    ax2.set_xlabel('Date')
    ax2.set_ylabel('Price')
    ax2.legend()

    st.pyplot(fig2)

    # RSI Calculation
    st.subheader('RSI (Relative Strength Index)')


    def calculate_rsi(data, window=14):
        delta = data['Close'].diff(1)
        gain = delta.where(delta > 0, 0)
        loss = -delta.where(delta < 0, 0)

        avg_gain = gain.rolling(window=window, min_periods=1).mean()
        avg_loss = loss.rolling(window=window, min_periods=1).mean()

        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        return rsi


    data['RSI'] = calculate_rsi(data)

    fig3 = go.Figure()
    fig3.add_trace(go.Scatter(x=data.index, y=data['RSI'], mode='lines', name='RSI', line=dict(color='purple')))
    fig3.add_trace(go.Scatter(x=data.index, y=[70] * len(data), mode='lines', name='Overbought',
                              line=dict(color='red', dash='dash')))
    fig3.add_trace(go.Scatter(x=data.index, y=[30] * len(data), mode='lines', name='Oversold',
                              line=dict(color='green', dash='dash')))
    fig3.update_layout(title='RSI (Relative Strength Index)', xaxis_title='Date', yaxis_title='RSI',
                       template='plotly_dark')
    st.plotly_chart(fig3)

    # MACD Calculation
    st.subheader('MACD (Moving Average Convergence Divergence)')

    data['EMA12'] = data['Close'].ewm(span=12, adjust=False).mean()
    data['EMA26'] = data['Close'].ewm(span=26, adjust=False).mean()
    data['MACD'] = data['EMA12'] - data['EMA26']
    data['Signal_Line'] = data['MACD'].ewm(span=9, adjust=False).mean()

    fig4 = go.Figure()
    fig4.add_trace(go.Scatter(x=data.index, y=data['MACD'], mode='lines', name='MACD', line=dict(color='blue')))
    fig4.add_trace(
        go.Scatter(x=data.index, y=data['Signal_Line'], mode='lines', name='Signal Line', line=dict(color='red')))
    fig4.update_layout(title='MACD (Moving Average Convergence Divergence)', xaxis_title='Date', yaxis_title='MACD',
                       template='plotly_dark')
    st.plotly_chart(fig4)

    # Prepare data for prediction
    past_100_days = data_train.tail(100)
    data_test_combined = pd.concat([past_100_days, data_test], ignore_index=True)
    data_test_scaled = scaler.transform(data_test_combined)

    x = []
    y = []
    for i in range(100, data_test_scaled.shape[0]):
        x.append(data_test_scaled[i - 100:i])
        y.append(data_test_scaled[i, 0])
    x = np.array(x)
    y = np.array(y)

    # Predictions using the loaded model
    predict = model.predict(x)
    scale = 1 / scaler.scale_[0]
    predict = predict * scale
    y = y * scale

    # Calculate Profit/Loss
    st.subheader('Price vs Predicted Price')

    fig5 = go.Figure()
    fig5.add_trace(go.Scatter(x=data_test.index, y=y, mode='lines', name='Real Stock Price', line=dict(color='blue')))
    fig5.add_trace(go.Scatter(x=data_test.index, y=predict.flatten(), mode='lines', name='Predicted Stock Price',
                              line=dict(color='red')))

    fig5.update_layout(title='Real vs Predicted Stock Price', xaxis_title='Date', yaxis_title='Price',
                       template='plotly_dark')
    st.plotly_chart(fig5)

    # Max Profit/Min Loss Calculation
    max_profit = np.max(predict - y)
    min_loss = np.min(predict - y)

    # Display Max Profit/Min Loss Calculation on a sidebar or below the graph
    st.markdown(f"""
    <div style="background-color: #000; border-radius: 10px; padding: 20px; margin-top: 20px; text-align: center;">
        <h3 style="color: #fff;">Potential Max Profit or Min Loss</h3>
        <p><b>Max Profit:</b> {max_profit:.2f}</p>
        <p><b>Min Loss:</b> {min_loss:.2f}</p>
    </div>
    """, unsafe_allow_html=True)
    # 1-Day Future Prediction
    st.subheader('1-Day Future Prediction')

    # Prepare the data for the prediction using the most recent 100 days
    last_100_days = data_train.tail(100)
    last_100_days_scaled = scaler.transform(last_100_days)

    # Prepare the input for prediction (reshape to match the model's expected input shape)
    x_input = np.array(last_100_days_scaled)
    x_input = x_input.reshape((1, x_input.shape[0], x_input.shape[1]))

    # Make the 1-day prediction
    future_price_scaled = model.predict(x_input)

    # Convert the scaled prediction back to the original scale
    future_price = future_price_scaled * scale

    # Display the 1-day future prediction
    st.write(f"**Predicted Stock Price for Next Day:** {future_price.flatten()[0]:.2f}")

    # Optional: Display additional context or other related information
    st.write("This is a predicted price for the next trading day based on the historical data provided.")

    import streamlit as st
    import requests
    import pandas as pd
    from nltk.sentiment.vader import SentimentIntensityAnalyzer
    import nltk

    # Download VADER lexicon for sentiment analysis
    nltk.download('vader_lexicon')

    # Initialize the SentimentIntensityAnalyzer
    analyzer = SentimentIntensityAnalyzer()

    # NewsAPI key (replace with your actual API key)
    NEWS_API_KEY = '3821765091c342069f62972414e50ff2'


    # Function to fetch news related to a stock
    def fetch_news(stock_name):
        url = 'https://newsapi.org/v2/everything'
        params = {
            'q': stock_name,  # Stock name or symbol (e.g., "Reliance", "NSE", "BSE", etc.)
            'apiKey': NEWS_API_KEY,
            'language': 'en',  # Filter news articles by English language
            'sortBy': 'relevance',  # Sort news by relevance
            'pageSize': 10  # Number of articles to fetch (you can adjust this)
        }
        response = requests.get(url, params=params)

        # Check if the request was successful
        if response.status_code == 200:
            articles = response.json().get('articles', [])
            return articles  # return the entire articles data for sentiment analysis
        else:
            st.error(f"Failed to fetch news: {response.status_code}")
            return []


    # Function to perform sentiment analysis on the fetched headlines
    def analyze_sentiment(news_articles):
        sentiment_data = []
        total_sentiment_score = 0  # Variable to store the cumulative sentiment score

        # Analyze sentiment of each headline using VADER
        for article in news_articles:
            headline = article['title']
            sentiment_score = analyzer.polarity_scores(headline)["compound"]

            # Classify sentiment based on the compound score
            sentiment_label = "positive" if sentiment_score > 0.1 else (
                "negative" if sentiment_score < -0.1 else "neutral")

            # Add individual sentiment score to cumulative total
            total_sentiment_score += sentiment_score

            sentiment_data.append({
                "headline": headline,
                "sentiment_score": sentiment_score,
                "sentiment_label": sentiment_label
            })

        # Calculate the average sentiment score
        average_sentiment_score = total_sentiment_score / len(news_articles) if news_articles else 0

        # Classify overall sentiment based on the average sentiment score
        overall_sentiment = "positive" if average_sentiment_score > 0 else (
            "negative" if average_sentiment_score < 0 else "neutral")

        return pd.DataFrame(sentiment_data), average_sentiment_score, overall_sentiment


    # Streamlit app interface
    st.title("Stock News Sentiment Analysis")
    st.write("Enter a stock ticker symbol to get the latest news, sentiment analysis, and buy/sell signal.")

    # Input for stock ticker
    stock_name = st.text_input("Stock Ticker (e.g., TCS, INFY):")

    if stock_name:
        # Fetch news for the stock
        news_articles = fetch_news(stock_name)

        if news_articles:
            # Perform sentiment analysis if news is found
            sentiment_data, average_sentiment_score, overall_sentiment = analyze_sentiment(news_articles)

            st.subheader(f"Sentiment Analysis for {stock_name}")

            # Display overall sentiment
            st.write(
                f"**Overall Sentiment: {overall_sentiment}** (Average Sentiment Score: {average_sentiment_score:.2f})")

            # Display sentiment breakdown
            sentiment_counts = sentiment_data['sentiment_label'].value_counts()
            st.write(f"Sentiment Counts: {sentiment_counts}")

            # Generate Buy/Sell Signal with better thresholds
            if average_sentiment_score > 0.1:  # Positive sentiment score (BUY)
                signal = "BUY"
                signal_color = "green"
            elif average_sentiment_score < 0.1:  # Negative sentiment score (SELL)
                signal = "SELL"
                signal_color = "red"
            else:  # Neutral sentiment score (HOLD)
                signal = "HOLD"
                signal_color = "yellow"

            st.markdown(f"### **Trade Signal: {signal}**", unsafe_allow_html=True)
            st.markdown(f"<span style='color:{signal_color}; font-size: 24px;'>{signal}</span>", unsafe_allow_html=True)

            # Add Buttons below Trade Signal
            st.markdown("""
                <style>
                    .button-container {
                        display: flex;
                        justify-content: space-evenly;
                        margin-top: 20px;
                        margin-bottom: 40px;
                    }
                    .button-container button {
                        padding: 10px 20px;
                        font-size: 16px;
                        border-radius: 5px;
                        border: none;
                        cursor: pointer;
                        transition: background-color 0.3s ease;
                        width: 150px;
                        text-align: center;
                    }
                    .angelone {
                        background-color: #F2A800;
                        color: white;
                    }

                    .grow {
                        background-color: #118B50;
                        color: white;
                    }

                    .zerodha {
                        background-color: #1E9FFF;
                        color: white;
                    }

                </style>
                <div class="button-container">
                    <a href="https://www.angelone.in" target="_blank">
                        <button class="angelone">AngelOne</button>
                    </a>
                    <a href="https://groww.in" target="_blank">
                        <button class="grow">Grow</button>
                    </a>
                    <a href="https://zerodha.com" target="_blank">
                        <button class="zerodha">Zerodha</button>
                    </a>
                </div>
            """, unsafe_allow_html=True)

            st.subheader("Full Sentiment Data")
            st.write(sentiment_data)

            # Display the news headlines with sentiment
            st.subheader("Latest News Headlines and Sentiment Analysis")
            for index, row in sentiment_data.iterrows():
                st.write(f"**Headline:** {row['headline']}")
                st.write(f"Sentiment: {row['sentiment_label']} (Score: {row['sentiment_score']})")
                st.write("\n---\n")
        else:
            st.warning("No news articles found. Try a different stock ticker or check back later.")
    else:
        st.info("Please enter a stock ticker to get started.")


